/**
 * A link to a certain page, an anchor tag
 */

import styled from 'styled-components';

const Flex = styled.div`
  display: flex;
`;

export default Flex;
