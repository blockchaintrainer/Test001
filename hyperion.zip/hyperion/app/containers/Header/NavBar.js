import styled from 'styled-components';

export default styled.div`
  text-align: center;
  background-color: rgb(68, 73, 114);
`;
