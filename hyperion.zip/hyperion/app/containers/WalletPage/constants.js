export const REQUEST_BALANCE = 'peerion/Wallet/REQUEST_BALANCE';
export const SUCCESS_BALANCE = 'peerion/Wallet/SUCCESS_BALANCE';
